namespace TestProject2;

public class UnitTest1
{
    [Fact]
    public void Test1()
    {
        double time = 2.0408163265306123;
        double v = 10;
        Assert.Equal(time,Ball(v) );
    }

    [Fact]
    public void Test2()
    {
        double time = 20;
        double v = 20;
        Assert.Equal(time,Ball(v) );
    }
    
    public double Ball(double v)
    {
        double g = 9.8;
         v = (2 * v) / g;
        return v ;
    }
}