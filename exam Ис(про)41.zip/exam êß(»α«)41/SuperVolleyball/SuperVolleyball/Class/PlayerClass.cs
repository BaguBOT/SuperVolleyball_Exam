using System;
using System.Runtime.InteropServices.JavaScript;
using Microsoft.VisualBasic;

namespace SuperVolleyball.Class;

public class PlayerClass
{
    public int Id;
    public string PlayerName;
    public string Position;
    public int Weight;
    public int Height;
    public DateOnly Birthday;
    public DateOnly DateStartGame;
    public string Team;
}