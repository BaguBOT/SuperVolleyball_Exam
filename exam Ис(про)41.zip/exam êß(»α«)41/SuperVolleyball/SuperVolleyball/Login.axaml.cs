using Avalonia.Controls;
using Avalonia.Interactivity;

namespace SuperVolleyball;

public partial class Login : Window
{
    public int admin1 = 0;
    public Login()
    {
        Width = 400;
        Height = 200;
        InitializeComponent();
    }


    private void AdminButton_OnClick(object? sender, RoutedEventArgs e)
    {
       new GamePlayer(admin1).Show();
     
    }

    private void MagerButton_OnClick(object? sender, RoutedEventArgs e)
    {
    
        new GamePlayer(admin1).Show();
    }

    private void UpdateButton_OnClick(object? sender, RoutedEventArgs e)
    {
        if (PasswordBox.Text == "Admin123" & LoginBox.Text == "Admin")
        {
            AdminButton.IsEnabled = true;
            UpdateButton.IsEnabled = false;
            admin1 = 1;
          
        }

        if (PasswordBox.Text == "Manager123" & LoginBox.Text == "Manager")
        {
            ManagerButton.IsEnabled = true;
            UpdateButton.IsEnabled = false;
            admin1 = 0;
            
        }
    }
}