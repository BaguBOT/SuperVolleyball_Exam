using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using Avalonia;
using Avalonia.Controls;
using Avalonia.Interactivity;
using Avalonia.Markup.Xaml;
using MySqlConnector;
using SuperVolleyball.Class;
using Tmds.DBus.Protocol;

namespace SuperVolleyball;

public partial class GamePlayer : Window
{
    public ObservableCollection<PlayerClass> Players { get; set; }
    public MySqlConnectionStringBuilder Connection;

    public GamePlayer(int admin)
    {
        Width = 800;
        Height = 600;
        InitializeComponent();
        Players = new ObservableCollection<PlayerClass>();
      Connection = new MySqlConnectionStringBuilder()
        {
            Server = "10.10.24.03",
            Database = "database1",
            UserID = "User",
            Password = "User123"
        };
       ShowTable();
        
        if (admin == 0)
        {
            DeleteButton.IsVisible = false;
        }
        else
        {
            DeleteButton.IsVisible = true;
        }
        
    }

    public void ShowTable()
    {
        using (var connection = new MySqlConnection(Connection.ConnectionString))
        {
            connection.Open();
            using (var command = connection.CreateCommand())
            {
                command.CommandText = @" SELECT iv.*, t.Team AS IdropTeam, p.Position AS PlayerPosition
                FROM idropvolleyball iv
                LEFT JOIN idropteam t ON iv.Team = t.ID
                LEFT JOIN idropposition p ON iv.Position = p.ID";
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Players.Add(new PlayerClass()
                        {
                           
                            PlayerName = reader.GetString("PlayerName"),
                            Position = reader.GetString("Position"),
                            Weight = reader.GetInt32("Weight"),
                            Height = reader.GetInt32("Height"),
                            Birthday = reader.GetDateOnly("Birthday"),
                            DateStartGame = reader.GetDateOnly("DateStartGame"),
                            Team = reader.GetString("Team")
                        });
                    }
                }
            }
            GamesPlayerDataGrid.ItemsSource = Players;
        }
    }
    private void AddButton_OnClick(object? sender, RoutedEventArgs e)
    {
        using (var connection = new MySqlConnection(Connection.ConnectionString))
        {
            connection.Open();
            using (var command = connection.CreateCommand())
            {
                command.CommandText = "INSERT INTO idropvolleyball (PlayerName, Position, Weight, Height, Birthday, DateStartGame, Team)" +
                                      "VALUES (@PlayerName, @Position, @Weight, @Height, @Birthday, @DateStartGame, @Team)";

                command.Parameters.AddWithValue("@PlayerName", PlayerBox.Text);
                command.Parameters.AddWithValue("@Position", Convert.ToInt32(PositionBox.Text));
                command.Parameters.AddWithValue("@Weight", Convert.ToInt32(WeightBox.Text));
                command.Parameters.AddWithValue("@Height", Convert.ToInt32(HeightBox.Text));
                command.Parameters.AddWithValue("@Birthday", Convert.ToDateTime(BirthdayBox.Text).ToString("yy-MM-dd"));
                command.Parameters.AddWithValue("@DateStartGame", Convert.ToDateTime(DateStartGameBox.Text).ToString("yy-MM-dd"));
                command.Parameters.AddWithValue("@Team", Convert.ToInt32(TeamBox.Text));

                command.ExecuteNonQuery();
            }
            connection.Close();
        }
        GamesPlayerDataGrid.ItemsSource = Players;
        
        Stat.IsVisible = true;
        Stat.Text = "Игрок добавлен";
    }

    private void DeleteButton_OnClick(object? sender, RoutedEventArgs e)
    {
        var remove = GamesPlayerDataGrid.SelectedItem as PlayerClass;
        if (remove != null)
        {
            using (var connection = new MySqlConnection(Connection.ConnectionString))
            using (var command = connection.CreateCommand())
            {
                command.CommandText = "DELETE FROM volleyball WHERE Id = @Id";
                command.Parameters.AddWithValue("@Id", remove.Id);
                connection.Open();
                command.ExecuteNonQuery(); 
            }
            Players.Remove(remove);
            GamesPlayerDataGrid.ItemsSource = Players;
          
        }
        Stat.IsVisible = true;
        Stat.Text = "Игрок Удален";
    }

    private void SearchBox_OnTextChanged(object? sender, TextChangedEventArgs e)
    {
        var search = new List<PlayerClass>(Players);
        search = search.Where(x => x.PlayerName.Contains(SearchBox.Text)).ToList();
        GamesPlayerDataGrid.ItemsSource = search;
    
    }

    private void ComboSelect_OnSelectionChanged(object? sender, SelectionChangedEventArgs e)
    {
        if (ComboSelect.SelectedItem != null)
        {
            string selectedTeam = (ComboSelect.SelectedItem as ComboBoxItem).Content.ToString();
            if (selectedTeam == "Reset")
            {
                GamesPlayerDataGrid.ItemsSource = Players;
            }

            if (selectedTeam == "Star")
            {
                var filter = Players.Where(x => x.Team == selectedTeam).ToList();
                GamesPlayerDataGrid.ItemsSource = filter;
            }
            
            if (selectedTeam == "UpTeam")
            {
                var filter = Players.Where(x => x.Team == selectedTeam).ToList();
                GamesPlayerDataGrid.ItemsSource = filter;
            }
        }
    }
}